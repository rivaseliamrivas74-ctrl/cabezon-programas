const products=[
{name:"Sistema Policial",cat:"Roleplay",price:1800,icon:"🚔",desc:"Sistema policial para administrar funciones de tu servidor."},
{name:"HUD Moderno",cat:"UI",price:1200,icon:"🖥️",desc:"HUD moderno y adaptable para MTA:SA."},
{name:"Inventario Moderno",cat:"Sistema",price:900,icon:"🎒",desc:"Inventario visual para tu servidor de roleplay."},
{name:"Sistema de Concesionario",cat:"Sistema",price:1500,icon:"🚗",desc:"Compra y gestión de vehículos desde un concesionario."},
{name:"Sistema de Teléfono",cat:"Sistema",price:1200,icon:"📱",desc:"Teléfono con interfaz moderna para roleplay."},
{name:"Sistema de Gasolina",cat:"Roleplay",price:800,icon:"⛽",desc:"Sistema de combustible para vehículos."},
{name:"Sistema de Garajes",cat:"Roleplay",price:1000,icon:"🏠",desc:"Garajes y almacenamiento de vehículos."},
{name:"Sistema de Skin",cat:"UI",price:800,icon:"👕",desc:"Gestión visual de skins para personajes."}
];
let cart=[];
const money=n=>"RD$"+n.toLocaleString("es-DO",{minimumFractionDigits:2});
function renderProducts(list=products){
 document.querySelector("#productGrid").innerHTML=list.map((p,i)=>`<article class="product"><div class="pic">${p.icon}</div><div class="product-body"><span class="tag">${p.cat.toUpperCase()}</span><h3>${p.name}</h3><p>${p.desc}</p><div class="price">${money(p.price)}</div><button class="btn primary" onclick="add(${i})">🛒 Comprar</button></div></article>`).join("");
}
function add(i){cart.push(products[i]);renderCart();openCart()}
function addCustom(name,price){cart.push({name,price});renderCart();openCart()}
function renderCart(){
 document.querySelector("#cartCount").textContent=cart.length;
 document.querySelector("#cartItems").innerHTML=cart.length?cart.map((p,i)=>`<div class="cart-item"><span>${p.name}</span><b>${money(p.price)} <button onclick="cart.splice(${i},1);renderCart()" style="background:none;border:0;color:#ff1680;cursor:pointer">✕</button></b></div>`).join(""):"<p style='color:#888'>Tu carrito está vacío.</p>";
 document.querySelector("#cartTotal").textContent=money(cart.reduce((s,p)=>s+p.price,0));
}
function openCart(){document.querySelector("#cart").classList.add("open");document.querySelector("#overlay").classList.add("show")}
function closeCart(){document.querySelector("#cart").classList.remove("open");document.querySelector("#overlay").classList.remove("show")}
document.querySelector("#cartBtn").onclick=openCart;document.querySelector("#closeCart").onclick=closeCart;document.querySelector("#overlay").onclick=closeCart;
document.querySelector("#menuBtn").onclick=()=>document.querySelector("#nav").classList.toggle("open");
document.querySelector("#search").oninput=e=>{const q=e.target.value.toLowerCase();renderProducts(products.filter(p=>(p.name+" "+p.desc+" "+p.cat).toLowerCase().includes(q)))};
document.querySelectorAll(".filter").forEach(b=>b.onclick=()=>{document.querySelectorAll(".filter").forEach(x=>x.classList.remove("active"));b.classList.add("active");renderProducts(b.dataset.cat==="Todos"?products:products.filter(p=>p.cat===b.dataset.cat))});
document.querySelectorAll(".add-pack").forEach(b=>b.onclick=()=>addCustom(b.dataset.name,+b.dataset.price));
document.querySelector("#checkout").onclick=()=>alert("Aquí debes conectar tu pasarela de pago real (por ejemplo, el proveedor de pagos que elijas) y tu sistema de entrega digital.");
document.querySelector("#contactForm").onsubmit=e=>{e.preventDefault();alert("Mensaje preparado. Conecta este formulario a tu correo, Discord o backend antes de publicar.");};
renderProducts();renderCart();
