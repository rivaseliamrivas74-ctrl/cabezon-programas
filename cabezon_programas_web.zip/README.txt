CABEZÓN PROGRAMAS — SITIO WEB

1. Sube todo el contenido de esta carpeta a tu hosting.
2. Cambia TU-DOMINIO.com en index.html, robots.txt y sitemap.xml por tu dominio real.
3. Reemplaza los datos de contacto/redes por los tuyos.
4. Conecta una pasarela de pago y un backend de entrega antes de cobrar.
5. Para aparecer en Google: verifica el dominio en Google Search Console y envía /sitemap.xml.
6. Google decide cuándo indexar y qué posición darle; nadie puede garantizar una posición concreta.

El catálogo se modifica directamente en script.js, dentro del arreglo "products".
